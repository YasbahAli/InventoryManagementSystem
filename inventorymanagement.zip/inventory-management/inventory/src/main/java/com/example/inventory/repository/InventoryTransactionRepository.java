package com.example.inventory.repository;

public class InventoryTransactionRepository {
    
}
