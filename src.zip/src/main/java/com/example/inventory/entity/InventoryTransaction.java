package com.example.inventory.entity;

public class InventoryTransaction {
    
}
