package com.example.inventory.entity;

public enum OrderStatus {
	PENDING,
	CONFIRMED,
	SHIPPED,
	COMPLETED,
	CANCELLED
}
